#!/usr/local/bin/python

import os
from Crypto.Cipher import AES
from Crypto.Util import Counter

flag = open("/app/flag.txt", "r").read()

forbidden_wish = b"I wish for 99999999999999 wishes"
magic = os.urandom(16)
lucky_number = 0

def prepare(data):
    ctr = Counter.new(128, initial_value=lucky_number)
    cipher = AES.new(magic, AES.MODE_CTR, counter=ctr)
    try:
        ct_bytes = cipher.encrypt(data.encode("utf-8"))
    except:
        print("Please submit a proper wish!\n")
        exit()
    return ct_bytes


def submit(data):
    try:
        data = bytes.fromhex(data)
    except:
        print("Please submit a proper wish!\n")
        exit()
    cipher = AES.new(magic, AES.MODE_OFB, int.to_bytes(lucky_number, length=16, byteorder="big"))
    pt_bytes = cipher.decrypt(data)
    return pt_bytes


def pick_lucky_number():
    global lucky_number
    try:
        num = int(input("Your lucky number >>> "))
    except:
        print("Please pick a proper number!\n")
        exit()
    lucky_number = num


print("""
Welcome to G3N1E, your AI-powered wish-granting Genie!
Submit your wish, and I'll do my best to make it come true.

However, with limited resources, I can't grant everyone's wishes at once. 
Pick a lucky number, and I'll randomly choose one fortunate person to receive their wish.

Feel free to wish for anything.
Just remember, wishing for 99999999999999 wishes is a bit too greedy, don't you think?
""")

pick_lucky_number()
while(True):
    print("[1] Prepare wish")
    print("[2] Submit wish")
    print("[3] Change lucky number")
    try:
        choice = int(input(">>> "))
    except:
        print("Invalid command\n")
        continue

    if choice == 1:
        pt = input("What do you wish for? >>> ")
        ct = prepare(pt)
        print(f"Sounds great. Submit this to the Genie: {ct.hex()}\n")
    elif choice == 2:
        ct = input("Submit your wish to the Genie >>> ")
        pt = submit(ct)
        if pt != forbidden_wish:
            print(f"Your wish \"{pt.decode('utf-8', errors='backslashreplace')}\" is granted :)\n")
        else:
            print(f"Your wish \"I wish for 9999.... Wait, that's illegal!\n")
            print(flag)
            exit()
    elif choice == 3:
        print("Feeling unlucky?")
        pick_lucky_number()
        print("Done! Hope you are luckier this time\n")
    else:
        print("Invalid command\n")

