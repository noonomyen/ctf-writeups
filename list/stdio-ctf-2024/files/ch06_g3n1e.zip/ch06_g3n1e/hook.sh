#!/bin/sh
echo $FLAG > /srv/app/flag.txt
chmod 444 /srv/app/flag.txt
