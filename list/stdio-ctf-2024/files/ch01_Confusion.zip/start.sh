echo $FLAG > /flag.txt
chmod 444 /flag.txt

apachectl -D FOREGROUND