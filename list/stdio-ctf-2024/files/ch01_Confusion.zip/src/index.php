<html>
<head>
  <title>MEME UPLOADER</title>
  <meta charset='utf-8' />
  <link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
  <div id="title">
    MEMELORD IS HUNGRY.
  </div>
  <div id="content">
    Click to upload meme, admin love to see it. We have a complete security check, don't try to upload the PHP shell.
    <br>
    <div id="upload-form">
      <form action="/index.php" method="post" enctype="multipart/form-data">
        <input type="file" name="uploadFile" id="uploadFile" required>
        <input type="submit" value="Upload Image" name="submit">
      </form>
    </div>
    <div id="upload-result">

<?php
// Not the /var/www/html. Even if the PHP shell slips in, the hacker won't be able to call it.
define("UPLOAD_PATH", "/var/www/uploads/");

if (isset($_POST["submit"])) {
  $ext = strtolower(pathinfo($_FILES["uploadFile"]["name"], PATHINFO_EXTENSION));
  $type = $_FILES["uploadFile"]["type"];
  $size = $_FILES["uploadFile"]["size"];
  $error = "";
  if ($ext !== "jpg" && $ext !== "png" && $ext !== "gif" && $ext !== "bmp") {
    $error = "Meme file should only be in jpg, png, gif, or bmp format";
  }
  if ($type !== "image/png" && $type !== "image/jpeg" && $type !== "image/gif" && $type !== "image/bmp") {
    $error = "Meme file should only be in jpg, png, gif, or bmp format";
  }
  if ($size >= 500*1000) {
    $error = "Meme file should be less than 500KB";
  }
  if ($error === "") {
    $target = uniqid("Meme-", true) . "." . $ext;
    if (move_uploaded_file($_FILES["uploadFile"]["tmp_name"], UPLOAD_PATH . $target)) {
        echo "Upload success. Your file name is $target";
    } else {
        echo "Uploaded Error";
    }
  } else {
        echo $error;
  }
}
?>
    </div>
  </div>
</body>
</html>
