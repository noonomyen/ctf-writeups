const express = require('express')
const puppeteer = require('puppeteer')
const path = require('path')
const crypto = require('crypto')
const helmet = require('helmet')

const app = express()
const port = 3000
const APP_HOST = process.env.APP_HOST
const FLAG = process.env.FLAG

app.set('view engine', 'ejs')
app.use(express.static('public'))
app.use(express.urlencoded({extended: false}))

app.use(
    helmet.contentSecurityPolicy({
      useDefaults: false,
      directives: {
        defaultSrc: ["*"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'"],
        imgSrc: ["'self'", "data:"],
        objectSrc: ["'none'"],
        frameAncestors: ["'none'"],
        connectSrc: ["*"],
        fontSrc: ["*"]
      }
    })
);


const visitUrl = async (url, cookieDomain) => {
    let browser =
            await puppeteer.launch({
                headless: 'new',
                pipe: true,
                dumpio: true,
                ignoreHTTPSErrors: true,
                args: [
                    '--incognito',
                    '--no-sandbox',
                    '--disable-setuid-sandbox',
                    '--disable-gpu',
                    '--disable-software-rasterizer',
                    '--disable-dev-shm-usage',
                    '--js-flags=--noexpose-wasm,--jitless',
                    '--ignore-certificate-errors',
                ]
            })

    try {
        const ctx = await browser.createBrowserContext()
        const page = await ctx.newPage()

        try {
            await page.setCookie({
                name: 'flag',
                value: FLAG,
                domain: cookieDomain,
                httpOnly: false,
                samesite: 'strict'
            })
            await page.goto(url, { timeout: 5000, waitUntil: 'networkidle2' })
        } finally {
            await page.close()
            await ctx.close()
        }
    } finally {
        browser.close()
    }
}

function checkValidChar(c) {
    var specialChars = "<>@!#$%^&*()_+[]{}?:;|'\"\\,./~`-=";
    if (specialChars.indexOf(c) > -1) {
        return false;
    }
    return true;
}

app.get('/', async (req, res) => {
    let name = req.query.name;

    try {
        if (!name || name === "") {
            name = "Anonymous";
            res.render('index', {
                name: name
            })
            return;
        }

        name = name.substring(0,200).toLowerCase();
        for (let i=0; i<200; i++) {
            if (checkValidChar(name[i]) !== true) {
                res.render('error');
                return;
            }
        }

        res.render('index', {
            name: name
        })
        return;

    } catch {
        res.render('error');
        return;
    }
})

app.post('/visit', async (req, res) => {
    const url = req.body.url

    try {
        let parsedURL
        parsedURL = new URL(url)

        if (parsedURL.protocol !== 'http:' && parsedURL.protocol != 'https:') {
            res.send('Please provide a URL with the http or https protocol.')
            return
        }

        if (parsedURL.hostname !== APP_HOST) {
            res.send(`Admin only accepts the URL from this website.`)
            return
        }

        console.log('visiting url: ', url)
        await visitUrl(url, req.hostname)
        console.log('done visiting url: ', url)
        res.send('Our admin bot has visited your URL!')
    } catch (e) {
        console.log('error visiting: ', url, ', ', e.message)
        res.send('Error visiting your URL.')
    }
})

app.listen(port, async () => {
    console.log(`Listening on ${port}`)
})