// go run prog1_ctf_server.go
package main

import (
    "bufio"
    "fmt"
    "math/rand"
    "net"
    "strconv"
    "strings"
    "time"
)

const (
    MAX_GUESSES = 10
    TIMEOUT     = 3 * time.Second
)

// Lists of random hint messages
var higherHints = []string{
    "Higher! Try again.",
    "Go higher! Give it another shot.",
    "Not quite, try a higher number.",
}

var lowerHints = []string{
    "Lower! Try again.",
    "Try a smaller number.",
    "Not quite, go lower.",
}

func getRandomHint(hints []string) string {
    rand.Seed(time.Now().UnixNano())
    return hints[rand.Intn(len(hints))]
}

func readInputWithTimeout(reader *bufio.Reader, timeout time.Duration) (string, error) {
    resultChannel := make(chan string)
    errorChannel := make(chan error)

    go func() {
        input, err := reader.ReadString('\n')
        if err != nil {
            errorChannel <- err
            return
        }
        resultChannel <- strings.TrimSpace(input)
    }()

    select {
    case input := <-resultChannel:
        return input, nil
    case err := <-errorChannel:
        return "", err
    case <-time.After(timeout):
        return "", fmt.Errorf("timeout")
    }
}

func handleClient(conn net.Conn) {
    defer conn.Close()

    rand.Seed(time.Now().UnixNano())
    target := rand.Intn(1000) + 1
    guessCount := 0

    conn.Write([]byte("Welcome to the Half Search Game!\n"))
    conn.Write([]byte("I'm thinking of a number between 1 and 1000.\n"))

    reader := bufio.NewReader(conn)

    for guessCount < MAX_GUESSES {
        conn.Write([]byte("Enter your guess (you have 3 seconds): "))

        input, err := readInputWithTimeout(reader, TIMEOUT)
        if err != nil {
            if err.Error() == "timeout" {
                conn.Write([]byte("Time's up! Connection will be closed.\n"))
                return // Close the connection and exit the function
            }
            conn.Write([]byte("Error reading input. Try again.\n"))
            continue
        }

        guess, err := strconv.Atoi(input)
        if err != nil {
            conn.Write([]byte("Please enter a valid number.\n"))
            continue
        }

        guessCount++

        if guess < target {
            conn.Write([]byte(getRandomHint(higherHints) + "\n"))
        } else if guess > target {
            conn.Write([]byte(getRandomHint(lowerHints) + "\n"))
        } else {
            conn.Write([]byte(fmt.Sprintf("Congratulations! You guessed the correct number: %d\n", target)))
            // For Local Testing Only: The Real Flag is on the remote server at `tcp://prog.ctf.p7z.pw:43211`
            conn.Write([]byte("Here's your flag: FLAG{FAKE_FLAG}\n"))
            return
        }
    }

    conn.Write([]byte("Sorry, you've exceeded the maximum number of guesses.\n"))
}

func main() {
    port := "43211" 
    listener, err := net.Listen("tcp", ":" + port)
    if err != nil {
        fmt.Println("Error starting server:", err)
        return
    }
    defer listener.Close()

    fmt.Println("Server listening on port", port + "...")

    for {
        conn, err := listener.Accept()
        if err != nil {
            fmt.Println("Error accepting connection:", err)
            continue
        }

        go handleClient(conn)
    }
}
