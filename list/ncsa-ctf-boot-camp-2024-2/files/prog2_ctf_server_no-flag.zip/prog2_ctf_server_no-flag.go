// go run prog2_ctf_server.go
package main

import (
	"bufio"
	"fmt"
	"math/rand"
	"net"
	"strings"
	"time"
)

func main() {
	// Define key-value pairs (A-Z)
	keyValues := map[string]string{
		"A": "    _\n   / \\ \n  / _ \\ \n / ___ \\ \n/_/   \\_\\\n",
		"B": " ____\n| __ )\n|  _ \\ \n| |_) |\n|____/\n",
		"C": "  ____\n / ___|\n| |\n| |___\n \\____|\n",
		"D": " ____\n|  _ \\ \n| | | |\n| |_| |\n|____/\n",
		"E": " _____\n| ____|\n|  _|\n| |___\n|_____|\n",
		"F": " _____\n|  ___|\n| |_\n|  _|\n|_|\n",
		"G": "  ____\n / ___|\n| |  _\n| |_| |\n \\____|\n",
		"H": " _   _\n| | | |\n| |_| |\n|  _  |\n|_| |_|\n",
		"I": " ___\n|_ _|\n | |\n | |\n|___|\n",
		"J": "     _\n    | |\n _  | |\n| |_| |\n \\___/\n",
		"K": " _  __\n| |/ /\n| ' /\n| . \\ \n|_|\\_\\\n",
		"L": " _\n| |\n| |\n| |___\n|_____|\n",
		"M": " __  __\n|  \\/  |\n| |\\/| |\n| |  | |\n|_|  |_|\n",
		"N": " _   _\n| \\ | |\n|  \\| |\n| |\\  |\n|_| \\_|\n",
		"O": "  ___\n / _ \\ \n| | | |\n| |_| |\n \\___/\n",
		"P": " ____\n|  _ \\ \n| |_) |\n|  __/ \n|_|\n",
		"Q": "  ___\n / _ \\ \n| | | |\n| |_| |\n \\__\\_\\\n",
		"R": " ____\n|  _ \\ \n| |_) |\n|  _ <\n|_| \\_\\\n",
		"S": " ____\n/ ___|\n\\___ \\ \n ___) |\n|____/\n",
		"T": " _____\n|_   _|\n  | |\n  | |\n  |_|\n",
		"U": " _   _\n| | | |\n| | | |\n| |_| |\n \\___/\n",
		"V": "__     __\n\\ \\   / /\n \\ \\_/ /\n  \\ V /\n   \\_/\n",
		"W": "__        __\n\\ \\      / /\n \\ \\ /\\ / /\n  \\ V  V /\n   \\_/_/\n",
		"X": "__  __\n\\ \\/ /\n \\  /\n /  \\ \n/_/\\_\\\n",
		"Y": "__   __\n\\ \\ / /\n \\ V /\n  | |\n  |_|\n",
		"Z": " _____\n|__  /\n  / /\n / /_\n/____|\n",
	}

	// Seed the random number generator
	rand.Seed(time.Now().UnixNano())

	// Listen on port 43212
	ln, err := net.Listen("tcp", ":43212")
	if err != nil {
		fmt.Println("Error starting server:", err)
		return
	}
	defer ln.Close()
	fmt.Println("Server is listening on port 43212")

	for {
		conn, err := ln.Accept()
		if err != nil {
			fmt.Println("Error accepting connection:", err)
			continue
		}
		go handleConnection(conn, keyValues)
	}
}

func handleConnection(conn net.Conn, keyValues map[string]string) {
	defer conn.Close()

	// Collect all keys
	keys := make([]string, 0, len(keyValues))
	for k := range keyValues {
		keys = append(keys, k)
	}

	// Select 16 random keys
	var selectedKeys []string
	for i := 0; i < 30; i++ {
		selectedKeys = append(selectedKeys, keys[rand.Intn(len(keys))])
	}

	var requestData strings.Builder

	// Prepare the data to send to the client
	for _, key := range selectedKeys {
		value := keyValues[key]
		requestData.WriteString(fmt.Sprintf(value))
	}

	// Send all the key-value pairs to the client
	fmt.Fprintf(conn, requestData.String())
	fmt.Fprintf(conn, "\nAnswer (30-character string): ")

	// Set a 3-second timeout for reading the client's response
	conn.SetReadDeadline(time.Now().Add(3 * time.Second))

	// Read client's response
	reader := bufio.NewReader(conn)
	clientAnswer, err := reader.ReadString('\n')
	if err != nil {
		if netErr, ok := err.(net.Error); ok && netErr.Timeout() {
			fmt.Fprintf(conn, "Timeout: No response received in 3 seconds.\n")
		} else {
			fmt.Fprintf(conn, "Error reading client answer: %v\n", err)
		}
		return
	}
	clientAnswer = strings.TrimSpace(clientAnswer)

	// Validate the length of the client's answer
	if len(clientAnswer) != 30{
		fmt.Fprintf(conn, "Incorrect number of characters. Please provide exactly 30 characters.\n")
		return
	}

	// Validate each character in the client's answer
	correct := true
	for i, answerChar := range clientAnswer {
		expectedKey := selectedKeys[i]
		if string(answerChar) != expectedKey {
			correct = false
		}
	}

	if correct {
		// For Local Testing Only: The Real Flag is on the remote server at `tcp://prog.ctf.p7z.pw:43212`
		fmt.Fprintf(conn, "All answers correct! Here is your flag: FLAG{FAKE_FLAG}\n")
	} else {
		fmt.Fprintf(conn, "Some answers were incorrect. Please try again.\n")
	}
}
