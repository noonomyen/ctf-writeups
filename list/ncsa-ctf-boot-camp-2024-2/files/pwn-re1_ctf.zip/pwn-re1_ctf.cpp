// gcc -o pwn-re1_ctf pwn-re1_ctf.cpp -lstdc++
#include <iostream>
#include <cstring>

bool check_password(const char* input) {
    // Correct password stored as hex values
    unsigned char correct_password[] = {
        0x79, 0x66, 0x10, 0x20, 0x0c, 0xcb, 0xa9, 0x36,
        0xce, 0x6b, 0xcc, 0x1e, 0x8d, 0x77, 0x85, 0xda
    };
    
    // Check input length, FLAG{32 characters} = 38
    if (strlen(input) != 38) {
        return false;
    }

    // Compare input starting from FLAG{...}
    const char* flag_format = "FLAG{";
    if (strncmp(input, flag_format, 5) != 0 || input[37] != '}') {
        return false;
    }

    // Compare the hex part of the flag
    for (int i = 0; i < 16; ++i) {
        // Extract two hex digits at a time from the input string, skipping "FLAG{" (5 characters) and '{' (5th character)
        unsigned char value;
        sscanf(&input[5 + i * 2], "%2hhx", &value);
        if (value != correct_password[i]) {
            return false;
        }
    }

    return true;
}

int main() {
    char input[50];

    std::cout << "Enter the flag: ";
    std::cin >> input;

    if (check_password(input)) {
        std::cout << "Correct! The flag is: " << input << std::endl;
    } else {
        std::cout << "Incorrect password." << std::endl;
    }

    return 0;
}
